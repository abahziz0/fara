# Terms of use

The licence for FARA's own part of this package has not been set yet. Until it is, please credit FARA and its sources.

Parts of this package come from other publishers and stay under their terms. Please keep these credits with the data.

## Village names and positions as collected

Source: Rohingya Khobor Arakan Maps Project, https://map.rohingyakhobor.com/map, collected 2 July 2026. Credit the project as the source.

## Official names, positions and place codes

The `pcode_` and `mimu_` fields of `arakan_villages`, and the files `pcodes.csv` and `pcodes_review.csv`.

Source: Myanmar Information Management Unit (MIMU), MIMU Place Codes (P-codes) Release 9.7, January 2026 (Rakhine workbook), https://themimu.info/place-codes. © MIMU. MIMU products may be used free of charge with attribution. They are not for sale and not for commercial use.

## 2017 satellite analysis

The files `status_unosat_2017.csv`, `status_unosat_2017.json` and `unosat_2017_zones.geojson`.

Derived from UNOSAT, "Destroyed areas in Buthidaung, Maungdaw, and Rathedaung Townships of Rakhine State in Myanmar", https://data.humdata.org/dataset/destroyed-areas-in-buthidaung-maungdaw-and-rathedaung-townships-of-rakhine-state-in-myanmar-2727. Licence: Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0), https://creativecommons.org/licenses/by-sa/4.0/. Credit UNOSAT, and share anything made from these files under the same licence.
