# Terms of use

FARA's own part of this package (the compilation, the corrections in `corrections.csv`, the matching in `pcodes.csv` and `status_unosat_2017`, and the texts) is published under the Creative Commons Attribution 4.0 International licence (CC BY 4.0): https://creativecommons.org/licenses/by/4.0/

You may copy, share and adapt it for any purpose, as long as you credit FARA.

Parts of this package come from other publishers and stay under their terms. Please keep these credits with the data.

## Village names and positions as collected

Source: Rohingya Khobor Arakan Maps Project, https://map.rohingyakhobor.com/map, collected 2 July 2026. Credit the project as the source.

## Official names, positions and place codes

The `pcode_` and `mimu_` fields of `arakan_villages`, and the files `pcodes.csv` and `pcodes_review.csv`.

Source: Myanmar Information Management Unit (MIMU), MIMU Place Codes (P-codes) Release 9.7, January 2026 (Rakhine workbook), https://themimu.info/place-codes. © MIMU. MIMU products may be used free of charge with attribution. They are not for sale and not for commercial use.

## Fire detections

The files `fires.csv`, `fires.json` and `fires_points.json`.

Derived from NASA FIRMS active fire data: VIIRS (Suomi NPP) 375 m and MODIS (Terra, Aqua) Collection 6.1, https://firms.modaps.eosdis.nasa.gov/. NASA's data are free and open. NASA asks to be credited: "We acknowledge the use of data from NASA's Fire Information for Resource Management System (FIRMS), part of NASA's Earth Science Data and Information System (ESDIS)."

## 2017 satellite analysis

The files `status_unosat_2017.csv`, `status_unosat_2017.json` and `unosat_2017_zones.geojson`.

Derived from UNOSAT, "Destroyed areas in Buthidaung, Maungdaw, and Rathedaung Townships of Rakhine State in Myanmar", https://data.humdata.org/dataset/destroyed-areas-in-buthidaung-maungdaw-and-rathedaung-townships-of-rakhine-state-in-myanmar-2727. Licence: Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0), https://creativecommons.org/licenses/by-sa/4.0/. Credit UNOSAT, and share anything made from these files under the same licence.
